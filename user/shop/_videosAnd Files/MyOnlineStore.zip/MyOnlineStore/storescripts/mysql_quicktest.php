<?php
// This file is www.developphp.com curriculum material
// Written by Adam Khoury January 01, 2011
// http://www.youtube.com/view_play_list?p=442E340A42191003
// Connect to the file above here   
require "connect_to_mysql.php";  

echo "<h1>Success in database connection! Happy Coding!</h1>";   
// if no success the script would have died before this success message 
?>