<div id="pageHeader"><table width="100%" border="0" cellspacing="0" cellpadding="12">
  <tr>
    <td width="32%"><a href="http://www.yoursite.com/index.php"><img src="http://www.yoursite.com/style/logo.jpg" alt="Logo" width="252" height="36" border="0" /></a></td>
    <td width="68%" align="right"><a href="http://www.adamkhoury.com/cart.php">Your Cart</a></td>
  </tr>
  <tr>
    <td colspan="2"><a href="http://www.yoursite.com/index.php">Home</a> &nbsp; &middot; &nbsp; <a href="#">Products</a> &nbsp; &middot; &nbsp; <a href="#">Help</a> &nbsp; &middot; &nbsp; <a href="#">Contact</a></td>
    </tr>
  </table>
</div>