CREATE PROCEDURE UserAllCollectedCoins(IN id INT)
  BEGIN
    SELECT COUNT(*) FROM collection WHERE userID = id;
  END;
