CREATE PROCEDURE UserAllUniqueCollectedCoins(IN id INT)
  BEGIN
    -- Collection::getCollectionCountById()
    SELECT COUNT(DISTINCT coinID) FROM collection WHERE userID = id;
  END;
