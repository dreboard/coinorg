CREATE PROCEDURE UserTotalInvestmentSumByCategory(IN id INT, IN cat VARCHAR(100), IN purchaseFrom VARCHAR(100))
  BEGIN
    -- Collection::getTotalInvestmentSumByCategoryFrom()
    SELECT COALESCE(sum(purchasePrice), 0.00)
    FROM collection
      INNER JOIN coins ON collection.coinID = coins.coinID
    WHERE collection.userID = id
          AND coins.coinCategory = cat
          AND collection.purchaseFrom = purchaseFrom;
  END;
