CREATE PROCEDURE CategoryTotalCollectedCoinsByID(IN category VARCHAR(50), IN id INT)
  BEGIN
  SELECT COUNT(*) FROM collection
            INNER JOIN coins ON collection.coinID = coins.coinID
            WHERE collection.userID = id AND coins.coinCategory = category;
END;
