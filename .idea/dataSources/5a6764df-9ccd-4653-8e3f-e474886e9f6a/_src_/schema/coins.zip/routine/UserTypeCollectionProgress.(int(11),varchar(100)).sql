CREATE PROCEDURE UserTypeCollectionProgress(IN id INT, IN cat VARCHAR(100))
  BEGIN
    -- Collection::getTypeCollectionProgress()
    SELECT COUNT(*)
    FROM collection
      INNER JOIN coins ON collection.coinID = coins.coinID
    WHERE collection.userID = id AND coins.coinCategory = cat
    LIMIT 1;
  END;
